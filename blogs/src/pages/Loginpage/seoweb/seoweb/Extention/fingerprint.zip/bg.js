! function(e) {
    var n = {};

    function t(r) {
        if (n[r]) return n[r].exports;
        var o = n[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(o.exports, o, o.exports, t), o.l = !0, o.exports
    }
    t.m = e, t.c = n, t.d = function(e, n, r) {
        t.o(e, n) || Object.defineProperty(e, n, {
            enumerable: !0,
            get: r
        })
    }, t.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, t.t = function(e, n) {
        if (1 & n && (e = t(e)), 8 & n) return e;
        if (4 & n && "object" == typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
        if (t.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: e
            }), 2 & n && "string" != typeof e)
            for (var o in e) t.d(r, o, function(n) {
                return e[n]
            }.bind(null, o));
        return r
    }, t.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return t.d(n, "a", n), n
    }, t.o = function(e, n) {
        return Object.prototype.hasOwnProperty.call(e, n)
    }, t.p = "", t(t.s = 3)
}({
    3: function(e, n) {
        var t = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "init";
                return (1e-99 * new Uint8Array(e.length).map((function(n, t) {
                    return e.charCodeAt(t)
                })).reduce((function(e, n, t) {
                    return e + n * Math.pow(8, t)
                }), 0)).toExponential().slice(1, -4)
            },
            r = {
                v: 63,
                seed: t()
            };
        Object.keys(r).forEach((function(e) {
            null == localStorage[e] && (localStorage[e] = r[e])
        }));
        var o = function() {
                return r.v = localStorage.v, r.seed = (32 | r.v) == r.v ? t(Math.random().toString(36).slice(2)) : localStorage.seed, r
            },
            c = {},
            u = chrome.runtime.id;
        chrome.runtime.onMessage.addListener((function(e, n, t) {
            "loconf" == e ? t(o()) : "puconf" == e ? Object.values(c).forEach((function(e) {
                return e.postMessage(o())
            })) : console.warn("".concat((new Date).toLocaleString(), ": ").concat(e))
        })), chrome.runtime.onConnect.addListener((function(e) {
            var n = e.sender.tab.id + ":" + e.sender.frameId;
            e.sender.id == u && (c[n] = e).onDisconnect.addListener((function(e) {
                return delete c[n]
            }))
        }))
    }
});